<!DOCTYPE html>
<html>
<heaad>
<meta charset="utf-8">
<title></title>
</head>

<body>

<form action="select.php" method="post">
<label for="buscar">Buscar usuario</label>
<input type="text" name="nombre" />
<input type="submit" value="Buscar" />
</form>

<form action="borrar.php" method="post">
<label for="usuario">Borrar usuario</label>
<input type="text" name="usuario" />
<input type="submit" value="Borrar" />
</form>

</body>
</html>