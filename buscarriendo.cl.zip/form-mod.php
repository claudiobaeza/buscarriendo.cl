<!DOCTYPE html>
<html>
<heaad>
<meta charset="utf-8">
<title></title>
</head>

<body>
<form action="modificar.php" method="post">
<label for="viejo">Contraseña antigua</label>
<input type="text" name="viejo" /> <br />
<label for="nuevo">Contraseña nueva</label>
<input type="text" name="nuevo" /> <br />
<input type="submit" value)"Actualizar Contraseña" />
</form>

</body>
</html>