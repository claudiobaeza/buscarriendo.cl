<?php
$host = "sql301.byethost7.com";
$user = "b7_14103089";
$pw = "cibblol";
$db = "b7_14103089_buscarriendo";
?>